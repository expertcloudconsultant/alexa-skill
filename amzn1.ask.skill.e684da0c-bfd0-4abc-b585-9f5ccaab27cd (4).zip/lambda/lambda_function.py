from ask_sdk_core.utils import is_request_type, is_intent_name
from ask_sdk_core.dispatch_components import (AbstractRequestHandler, AbstractExceptionHandler, AbstractRequestInterceptor, AbstractResponseInterceptor)
from ask_sdk_core.skill_builder import CustomSkillBuilder
from datetime import datetime

import logging
import random
import os
from pymongo import MongoClient

# MongoDB connection
client = pymongo.MongoClient(
    "mongodb+srv://samueloppong:51UVyecsZ3sLCOPC@cluster0.52xfihh.mongodb.net/?retryWrites=true&w=majority"
)
database = client["appointments"]
appointments_collection = database["patients"]

# Intent Handlers

# This Handler is called when the skill is invoked by using only the invocation name(Ex. Alexa, open template ten)
class LaunchRequestHandler(AbstractRequestHandler):
    
    def can_handle(self, handler_input):
        return is_request_type("LaunchRequest")(handler_input)
    
    def handle(self, handler_input):
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        persistent_attributes = handler_input.attributes_manager.persistent_attributes
        skill_name = language_prompts["Running_Skill"]
        
        speech_output = random.choice(language_prompts["Welcome"]).format(Running_Skill)
        reprompt = random.choice(language_prompts["Welcome_Reprompt"])
        
        return (
            handler_input.response_builder
                .speak(speech_output)
                .ask(Reprompt)
                .response
                )

class AddNewAppointmentIntentHandler(AbstractRequestHandler): #Insert Name of Patient
    
    def can_handle(self, handler_input):
        return is_intent_name("AddNewAppointmentIntent")(handler_input)
    
    def handle(self, handler_input):
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        persistent_attributes = handler_input.attributes_manager.persistent_attributes
        
        speech_output = random.choice(language_prompts["Insert_Name"])
        reprompt = random.choice(language_prompts["Insert_Name_Reprompt"])
        
        return (
            handler_input.response_builder
                .speak(speech_output)
                .ask(Reprompt)
                .response
                )

class InsertDOBIntentHandler(AbstractRequestHandler):  #Insert Date of Birth of Patient
    
    def can_handle(self, handler_input):
        return is_intent_name("InsertDOBIntent")(handler_input)
    
    def handle(self, handler_input):
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        persistent_attributes = handler_input.attributes_manager.persistent_attributes
        session_attributes = handler_input.attributes_manager.session_attributes
        
        name = handler_input.request_envelope.request.intent.slots["PatientNameSlot"].value
        session_attributes["name"] = name
        
        speech_output = random.choice(language_prompts["Insert_DOB"]).format(name)
        reprompt = random.choice(language_prompts["Insert_DOB_Reprompt"])
        
        return (
            handler_input.response_builder
                .speak(speech_output)
                .ask(Reprompt)
                .response
                )

# SaveAppointmentIntentHandler
class SaveAppointmentIntentHandler(AbstractRequestHandler):  #Write Patient Name and DOB to DB
    def can_handle(self, handler_input):
        return is_intent_name("SaveAppointmentIntent")(handler_input)
    
    def handle(self,handler_input):
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        session_attributes = handler_input.attributes_manager.session_attributes
        
        date_of_birth = handler_input.request_envelope.request.intent.slots["PatientDOBSlot"].value
        name = session_attributes["name"]
        
        # Save data to MongoDB
        collection.update_one({"name": name}, {"$set": {"date_of_birth": date_of_birth}}, upsert=True)
        
        speech_output = random.choice(language_prompts["Appointment_Stored"])
        reprompt = random.choice(language_prompts["Appointment_Stored_Reprompt"])
        
        return(
            handler_input.response_builder
                .speak(speech_output)
                .ask(Reprompt)
                .response
            )

# CheckAppointmentIntentHandler
class CheckAppointmentIntentHandler(AbstractRequestHandler): #Retrieve Patient based on DOB
    def can_handle(self, handler_input):
        return is_intent_name("CheckAppointmentIntent")(handler_input)
    
    def handle(self,handler_input):
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        
        name = handler_input.request_envelope.request.intent.slots["ExistingPatientNameSlot"].value
        
        # Retrieve data from MongoDB
        patient_data = collection.find_one({"name": name})
        
        if patient_data:
            date_of_birth = patient_data["date_of_birth"]
            speech_output = random.choice(language_prompts["Announce_DOB"]).format(name, date_of_birth)
            reprompt = random.choice(language_prompts["Announce_DOB_Reprompt"])
        else:
            speech_output = random.choice(language_prompts["Unknown_Patient"]).format(name)
            reprompt = random.choice(language_prompts["Unknown_Patient_Reprompt"])
        
        return(
            handler_input.response_builder
                .speak(speech_output)
                .ask(Reprompt)
                .response
            )

class NextAppointmentIntentHandler(AbstractRequestHandler): #Check Next Appointment (Schedule)
    def can_handle(self, handler_input):
        return is_intent_name("NextAppointmentIntent")(handler_input)
    
    def handle(self,handler_input):
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        persistent_attributes = handler_input.attributes_manager.persistent_attributes
        
        nearest_appointment_name = ""
        nearest_appointment_days = 0
        todays_date = datetime.now()
        current_year = datetime.today().year
        name_list = persistent_attributes.keys()
        
        for name in name_list:
            date_of_birth = datetime.strptime(persistent_attributes[name],"%Y-%m-%d")
            Appointment_this_year = date_of_birth.replace(year = current_year)
            Appointment_next_year = date_of_birth.replace(year = current_year+1)
            
            if appointment_this_year > todays_date:
                no_of_days = (Appointment_this_year - todays_date).days
            else:
                no_of_days = (Appointment_next_year - todays_date).days
            
            if nearest_appointment_days == 0:
                nearest_appointment_days = no_of_days
                nearest_appointment_name = name
            elif no_of_days < nearest_Appointment_days:
                nearest_appointment_days = no_of_days
                nearest_appointment_name = name
        
        speech_output = random.choice(language_prompts["Announce_Closest_DOB"]).format(nearest_appointment_name, nearest_appointment_days)
        reprompt = random.choice(language_prompts["Announce_Closest_DOB_Reprompt"])
        
        
        return(
            handler_input.response_builder
                .speak(speech_output)
                .ask(Reprompt)
                .response
            )

class DeleteAllAppointmentsIntentHandler(AbstractRequestHandler): #Delete all entries in DB Table
    def can_handle(self, handler_input):
        return is_intent_name("DeleteAllAppointmentsIntent")(handler_input)
    
    def handle(self,handler_input):
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        persistent_attributes = handler_input.attributes_manager.persistent_attributes
        
        handler_input.attributes_manager.delete_persistent_attributes()
        
        speech_output = random.choice(language_prompts["Delete_DB"])
        reprompt = random.choice(language_prompts["Delete_DB_Reprompt"])
        
        return(
            handler_input.response_builder
                .speak(speech_output)
                .ask(Reprompt)
                .response
            )

class DeleteSpecificAppointmentIntentHandler(AbstractRequestHandler): #Delete specific patient data entry
    def can_handle(self, handler_input):
        return is_intent_name("DeleteSpecificAppointmentIntent")(handler_input)
    
    def handle(self,handler_input):
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        persistent_attributes = handler_input.attributes_manager.persistent_attributes
        
        name = handler_input.request_envelope.request.intent.slots["DeletePatientNameSlot"].value
        persistent_attributes.pop(name, None)
        handler_input.attributes_manager.save_persistent_attributes()
        
        speech_output = random.choice(language_prompts["Delete_Specific"]).format(name)
        reprompt = random.choice(language_prompts["Delete_Specific_Reprompt"])
        
        return(
            handler_input.response_builder
                .speak(speech_output)
                .ask(Reprompt)
                .response
            )



class RepeatIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return is_intent_name("AMAZON.RepeatIntent")(handler_input)
    
    def handle(self, handler_input):
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        session_attributes = handler_input.attributes_manager.session_attributes
        
        repeat_speech_output = session_attributes["repeat_speech_output"]
        repeat_reprompt = session_attributes["repeat_reprompt"]
        
        speech_output = random.choice(language_prompts["Repeat"]).format(repeat_speech_output)
        reprompt = random.choice(language_prompts["Repeat_Reprompt"]).format(repeat_reprompt)
        
        return (
            handler_input.response_builder
                .speak(speech_output)
                .ask(Reprompt)
                .response
            )


class CancelOrStopIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return (is_intent_name("AMAZON.CancelIntent")(handler_input) or
                is_intent_name("AMAZON.StopIntent")(handler_input))
    
    def handle(self, handler_input):
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        speech_output = random.choice(language_prompts["Cancel_Stop_Response"])
        
        return (
            handler_input.response_builder
                .speak(speech_output)
                .set_should_end_session(True)
                .response
            )

class HelpIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return is_intent_name("AMAZON.HelpIntent")(handler_input)
    
    def handle(self, handler_input):
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        speech_output = random.choice(language_prompts["Help"])
        reprompt = random.choice(language_prompts["Help_Reprompt"])
        
        return (
            handler_input.response_builder
                .speak(speech_output)
                .ask(Reprompt)
                .response
            )

# This handler handles utterances that can't be matched to any other intent handler.
class FallbackIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return is_intent_name("AMAZON.FallbackIntent")(handler_input)
    
    def handle(self, handler_input):
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        speech_output = random.choice(language_prompts["Fallback"])
        reprompt = random.choice(language_prompts["Fallback_Reprompt"])
        
        return (
            handler_input.response_builder
                .speak(speech_output)
                .ask(Reprompt)
                .response
            )

class SessionEndedRequesthandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return is_request_type("SessionEndedRequest")(handler_input)
    
    def handle(self, handler_input):
        logger.info("Session ended with the reason: {}".format(handler_input.request_envelope.request.reason))
        return handler_input.response_builder.response

# Exception Handlers

# This exception handler handles syntax or routing Errors. If you receive an Error stating 
# the request handler is not found, you have not implemented a handler for the intent or 
# included it in the skill builder below
class CatchAllExceptionHandler(AbstractExceptionHandler):
    
    def can_handle(self, handler_input, exception):
        return True
    
    def handle(self, handler_input, exception):
        logger.Error(exception, exc_info=True)
        
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        
        speech_output = language_prompts["Error"]
        reprompt = language_prompts["Error_Reprompt"]
        
        return (
            handler_input.response_builder
                .speak(speech_output)
                .ask(Reprompt)
                .response
            )

# Interceptors

# This interceptor logs each request sent from Alexa to our endpoint.
class RequestLogger(AbstractRequestInterceptor):

    def process(self, handler_input):
        logger.debug("Alexa Request: {}".format(
            handler_input.request_envelope.request))

# This interceptor logs each response our endpoint sends back to Alexa.
class ResponseLogger(AbstractResponseInterceptor):

    def process(self, handler_input, response):
        logger.debug("Alexa Response: {}".format(response))

# This interceptor is used for supporting different languages and locales. It detects the users locale,
# loads the corresponding language prompts and sends them as a request attribute object to the handler functions.
class LocalizationInterceptor(AbstractRequestInterceptor):

    def process(self, handler_input):
        locale = handler_input.request_envelope.request.locale
        logger.info("Locale is {}".format(locale))
        
        try:
            with open("languages/"+str(locale)+".json") as language_data:
                language_prompts = json.load(language_data)
        except:
            with open("languages/"+ str(locale[:2]) +".json") as language_data:
                language_prompts = json.load(language_data)
        
        handler_input.attributes_manager.request_attributes["_"] = language_prompts

# This interceptor fetches the speech_output and Reprompt messages from the response and pass them as
# session attributes to be used by the Repeat intent handler later on.
class RepeatInterceptor(AbstractResponseInterceptor):

    def process(self, handler_input, response):
        session_attributes = handler_input.attributes_manager.session_attributes
        session_attributes["Repeat_speech_output"] = response.output_speech.ssml.replace("<speak>","").replace("</speak>","")
        try:
            session_attributes["Repeat_Reprompt"] = response.Reprompt.output_speech.ssml.replace("<speak>","").replace("</speak>","")
        except:
            session_attributes["Repeat_Reprompt"] = response.output_speech.ssml.replace("<speak>","").replace("</speak>","")


# Skill Builder
# Define a skill builder instance and add all the request handlers,
# exception handlers, and interceptors to it.

sb = CustomSkillBuilder()
sb.add_request_handler(LaunchRequestHandler())
sb.add_request_handler(AddNewAppointmentIntentHandler())
sb.add_request_handler(InsertDOBIntentHandler())
sb.add_request_handler(SaveAppointmentIntentHandler())
sb.add_request_handler(CheckAppointmentIntentHandler())
sb.add_request_handler(NextAppointmentIntentHandler())
sb.add_request_handler(DeleteSpecificAppointmentIntentHandler())
sb.add_request_handler(DeleteAllAppointmentsIntentHandler())
sb.add_request_handler(RepeatIntentHandler())
sb.add_request_handler(CancelOrStopIntentHandler())
sb.add_request_handler(HelpIntentHandler())
sb.add_request_handler(FallbackIntentHandler())
sb.add_request_handler(SessionEndedRequesthandler())

sb.add_exception_handler(CatchAllExceptionHandler())

sb.add_global_response_interceptor(RepeatInterceptor())
sb.add_global_request_interceptor(LocalizationInterceptor())
sb.add_global_request_interceptor(RequestLogger())
sb.add_global_response_interceptor(ResponseLogger())

lambda_handler = sb.lambda_handler()
